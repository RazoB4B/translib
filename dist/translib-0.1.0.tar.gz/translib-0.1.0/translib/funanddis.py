#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 17:02:38 2025

@author: alberto-razo
"""
import numpy as np
import scipy.special as sc


def IntensityPhaseRidDist(_I, _phaseRigidity):
    # See Eq. 16 of PRE 93, 032108 (2016)
    _f = 1 - _phaseRigidity**2
    _P = (1/np.sqrt(_f))*np.exp(-_I/_f)*sc.i0(_phaseRigidity*_I/_f)
    return _P


def AngleComplexnessDist(_phi, _complexness):
    # See Eq. 4 of PRE 80, 035201(R) (2009)
    return _complexness/(_complexness**2 * np.cos(_phi)**2 + np.sin(_phi)**2)/(2*np.pi)
