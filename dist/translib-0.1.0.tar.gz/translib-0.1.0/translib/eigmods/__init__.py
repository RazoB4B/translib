#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 18:04:13 2025

@author: alberto-razo
"""

